<?php

//===============  Telegram Basic Variables:  =============
@$chat_id = $update["message"]['chat']['id'];
@$text = $update["message"]['text'];
@$username = $update["message"]['from']['username'];
//first name & last name
$first_name = $update["message"]['from']['first_name'];

@$user_id = $update["message"]['from']['id'];
@$message_id = $update["message"]['message_id'];
//===============                             =============


if($text="/start"){
    bot("sendMessage", array('chat_id' => $chat_id,'text' =>"Hello World!"));
}