<?php
return [
    'database' => [
        'host' => 'localhost',
        'username' => 'yadetnareGOD',
        'password' => 'zc7pzg7UdfZIZ24yUe1W',
        'dbname' => 'yadetNareApp',
    ],
    'bot_token' => '7699184105:AAFXDIYHyFLa0mYAJ9cVKc9HhYb26BtM1N4',
    'admin_id' => '141872429',
];